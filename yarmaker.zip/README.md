## YarMaker - create YARA signatures from selection

IDA plugin with no dependencies to easily create fine grained YARA signatures 
by selecting a set of x86 instructions and choosing a wildcard mask. 
Just select chunk and press `Ctrl+Y` to create a Yara hex pattern.

![Screenshot of opened editor dialog](images/screenshot_1.webp "YarMaker editor dialog")

### Features
- Make rule from any entities in selection in "**Disassembly**" and "**Decompile**" views
- Make rule from selection in "**Strings**" view
- Make "hunting" ruleset from selection in "**Functions**" view, 
  rule contains basic blocks and data refs content (strings, constants, etc...)
- Fine-grained wildcarding of instructions: offsets, displacements, registers, constants
- Yara syntax highlighting
- Easy customization (see "[Customization](#customization)" section)

### Installation

Install using the [Hex-Rays CLI tool (hcli)](https://github.com/HexRaysSA/ida-hcli):
```bash
pip install ida-hcli
hcli plugin install yarmaker
```

**OR** install manually by copy `yarmaker.py` and the `yarmaker` folder to your IDA plugins directory (depends on your system):
- **Windows**: `%APPDATA%\Hex-Rays\IDA Pro\plugins\`
- **macOS**: `~/Library/Application Support/IDA Pro/plugins/`
- **Linux**: `~/.idapro/plugins/`

### Customization
You can customize the rules format to suit your needs.
To do this, replace global parameters in header of `yarmaker.py` file

Rule style parameters:
- `WRAP_CURLY_BRACE` - wrap curly brace on a new line (default: `False`)
- `INDENT_HEADERS` - indent `meta`, `strings`, `condition` (default: `False`)

Rule editor default parameters (also editable in the editor window):
- `DEFAULT_SHOW_COMMENTS` - show comments (default: `True`) 
- `DEFAULT_WILDCARD` - instruction parts replaced with `??`, any combination of
  `Wildcard.OFFSETS`, `Wildcard.DISPLACEMENTS`, `Wildcard.REGISTERS`, `Wildcard.CONSTANTS`
  (default: `Wildcard.OFFSETS | Wildcard.DISPLACEMENTS`). Selectable in the editor window
  via dropdown, entries are defined by `WILDCARD_MODES`
- `DEFAULT_INDENT` - rule indentation (default: `2`)
- `DEFAULT_NAMED_VARIABLES` = use names for strings (default: `True`)
- `DEFAULT_SHOW_TEMPLATE` - show the full rule (`meta`, `condition`) instead of
  only the generated strings (default: `False`)

Default fields in `meta` section. Values can be string or lambda functions
```python
DEFAULT_META_FIELDS = {
    'company': 'Security Inc.',
    'date': lambda: str(date.today()),
}
```

Default fields in `conditions` section. 
Values can be string or lambda functions (with optional argument - strings count): 
```python
DEFAULT_CONDITIONS = [
    lambda: '(PE)' in idaapi.get_file_type_name() and 'uint16(0) == 0x5A4D',
    lambda count: f'{2 * count // 3} of them' if count > 2 else 'all of them'
]
```

### TODO
- More entities for hunting ruleset (available now via hotkey `Ctrl+Alt+Y`)
- Identify more bugs during use (waiting for your issues!)

### Credits
Thanks to [mkYARA](https://github.com/fox-it/mkYARA) IDA plugin, 
which was the inspiration for this project

### License
YarMaker is licensed under the [GNU General Public License v3.0](LICENSE).

This project is a fork of [Yarka](https://github.com/AzzOnFire/yarka) by AzzOnFire
and has been modified to better fit my personal workflow. Changes include a more fine-grained control over wildcard masking, giving the user the option to decide which parts of the instructions should be replaced with wildcards. Other changes are improvements to the rule editor interface and additional customization options for rule formatting.

- Copyright (C) 2023 AzzOnFire
- Copyright (C) 2026 Jonathan Peters
